<?php

function sum($x) {
	$x = $x + 10;
	echo "The sum is $x<br>";
}
	
// code
$n = 20;
sum($n);

echo "</br>";
echo "value of n is $n";
